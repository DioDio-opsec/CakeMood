-- Execute este script no SQL Editor do Supabase.
-- Supabase Auth guarda as credenciais; não crie uma tabela própria de senhas.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.carts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  items jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id bigint generated always as identity primary key,
  order_number text unique not null,
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'recebido',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.carts enable row level security;
alter table public.orders enable row level security;

create policy "Clientes podem ler o próprio perfil"
on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Clientes podem criar o próprio perfil"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Clientes podem atualizar o próprio perfil"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Cliente lê o próprio carrinho"
on public.carts for select to authenticated using (auth.uid() = user_id);
create policy "Cliente cria o próprio carrinho"
on public.carts for insert to authenticated with check (auth.uid() = user_id);
create policy "Cliente atualiza o próprio carrinho"
on public.carts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Pedidos são inseridos exclusivamente pela Edge Function com service role.
-- Não conceda leitura pública da tabela orders.
