// Supabase Edge Function: send-order-email
// Configure os secrets no Supabase: RESEND_API_KEY e ORDER_NOTIFICATION_EMAIL.
// SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY são disponibilizados pelo ambiente Supabase.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const json = (body: unknown, status=200) => new Response(JSON.stringify(body), {
    status, headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
  if (req.method !== "POST") return json({error:"Método não permitido"},405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendKey = Deno.env.get("RESEND_API_KEY");
    const notifyEmail = Deno.env.get("ORDER_NOTIFICATION_EMAIL");
    if (!resendKey || !notifyEmail) return json({error:"Serviço de e-mail não configurado"},500);

    const supabase = createClient(supabaseUrl,serviceKey);
    const authHeader = req.headers.get("Authorization");
    let userId: string | null = null;
    if (authHeader) {
      const token = authHeader.replace(/^Bearer\s+/i,"");
      const {data:{user}} = await supabase.auth.getUser(token);
      userId = user?.id ?? null;
    }

    const body = await req.json();
    const customerName = String(body.customer_name || "").trim().slice(0,120);
    const incoming = Array.isArray(body.items) ? body.items : [];
    if (!customerName || incoming.length < 1 || incoming.length > 10) return json({error:"Pedido ou nome inválido"},400);

    // Preços e nomes são definidos no servidor, nunca confiamos nos valores enviados pelo navegador.
    const catalog: Record<string,{name:string,price:number}> = {
      oreo:{name:"Bolo de Oreo",price:10},
      cenoura:{name:"Bolo de cenoura com cobertura de chocolate",price:10}
    };
    const items = incoming.map((x:any)=>{
      const p=catalog[String(x.product_id)];
      const quantity=Number(x.quantity);
      if(!p || !Number.isInteger(quantity) || quantity<1 || quantity>100) throw new Error("Item inválido");
      return {product_id:String(x.product_id),name:p.name,quantity,unit_price:p.price,subtotal:p.price*quantity};
    });
    const total=items.reduce((s:any,x:any)=>s+x.subtotal,0);
    const orderNumber=`CM-${Date.now().toString().slice(-8)}`;

    const {error:insertError}=await supabase.from("orders").insert({
      order_number:orderNumber,user_id:userId,customer_name:customerName,items,total
    });
    if(insertError) throw insertError;

    const lines=items.map((x:any)=>`${x.quantity}x ${x.name} — R$ ${x.subtotal.toFixed(2).replace(".",",")}`).join("\n");
    const emailResponse=await fetch("https://api.resend.com/emails",{
      method:"POST",
      headers:{"Authorization":`Bearer ${resendKey}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        from:"Cake MOOD <pedidos@resend.dev>",
        to:[notifyEmail],
        subject:`Novo pedido ${orderNumber} — Cake MOOD`,
        text:`Novo pedido recebido!\n\nPedido: ${orderNumber}\nCliente: ${customerName}\n\n${lines}\n\nTotal: R$ ${total.toFixed(2).replace(".",",")}`
      })
    });
    if(!emailResponse.ok){
      const detail=await emailResponse.text();
      console.error("Falha no Resend:",detail);
      // O pedido permanece salvo; não apagamos uma compra porque a notificação falhou.
      return json({success:true,order_number:orderNumber,email_sent:false,message:"Pedido salvo, mas o e-mail não foi enviado."});
    }
    return json({success:true,order_number:orderNumber,email_sent:true});
  } catch (error) {
    console.error(error);
    return json({error:"Não foi possível processar o pedido."},400);
  }
});
